package com.stream.app;

public class AppConstants {
    public static final int CHUNK_SIZE = 1024*1024;
}
